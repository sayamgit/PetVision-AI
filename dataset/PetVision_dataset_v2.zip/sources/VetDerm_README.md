---
license: apache-2.0
task_categories:
  - image-classification
  - visual-question-answering
tags:
  - veterinary
  - dermatology
  - dogs
  - paligemma
  - medical
pretty_name: VetDerm Dog Skin Diseases
size_categories:
  - 1K<n<10K
---

# VetDerm — Dog Skin Diseases for PaliGemma Fine-tuning

6 classes of canine dermatological conditions, formatted for PaliGemma VLM fine-tuning.

## Classes
- **Dermatitis** (721 images) — inflammation, erythema, pruritus
- **Fungal_infections** (472 images) — alopecia, scaling, crusting
- **Healthy** (631 images) — normal skin
- **Hypersensitivity** (293 images) — urticaria, allergic reactions
- **Demodicosis** (762 images) — Demodex mange
- **Ringworm** (1003 images) — Dermatophytosis

## Format
JSONL with fields: `image`, `prefix`, `suffix`, `class`, `split`

## Source
Based on [Dog's Skin Diseases Image Dataset](https://www.kaggle.com/datasets/youssefmohmmed/dogs-skin-diseases-image-dataset) (Apache-2.0)
