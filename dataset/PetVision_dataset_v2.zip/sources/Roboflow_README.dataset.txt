# Cat Skin Disease Classification > 2025-07-26 10:47am
https://universe.roboflow.com/alvian-i1njf/cat-skin-disease-classification-b18ja

Provided by a Roboflow user
License: CC BY 4.0

